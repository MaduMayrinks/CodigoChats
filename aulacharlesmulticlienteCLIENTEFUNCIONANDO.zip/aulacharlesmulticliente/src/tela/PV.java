package tela;

import aula_03_sockets_multicliente.Cliente;
import aula_03_sockets_multicliente.Mensagem;
import aula_03_sockets_multicliente.usuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.SwingWorker;

public class PV extends javax.swing.JFrame {

    private Cliente cliente = null;
    usuarios RecebeDados;
    Mensagem RecebeMensagem;

    public PV(Mensagem selecionada, usuarios dadosUsuario) {
        initComponents();
        baixaImagemfundo();
        this.setLocationRelativeTo(null);

        RecebeDados = dadosUsuario;
        RecebeMensagem = selecionada;
        nomeUsuarioLbl.setText(RecebeMensagem.getEmailDestinatario());

        AtualizaChat();  //--> objetivo dele: atualizar o list de mensagens...
    }

    public PV() {
        initComponents();
        baixaImagemfundo();
        this.setLocationRelativeTo(null);
        AtualizaChat();
    }

    private void baixaImagemfundo() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\imagem\\pv.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1179, 764, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(PV.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        sair = new javax.swing.JButton();
        nomeUsuarioLbl = new javax.swing.JLabel();
        enviar = new javax.swing.JButton();
        txtMensage = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        listMsg = new javax.swing.JList<>();
        fotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setText("Voltar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 700, -1, -1));

        sair.setText("Sair");
        sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairActionPerformed(evt);
            }
        });
        jPanel1.add(sair, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 720, -1, 30));

        nomeUsuarioLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        nomeUsuarioLbl.setForeground(new java.awt.Color(255, 255, 255));
        nomeUsuarioLbl.setText("jLabel1");
        jPanel1.add(nomeUsuarioLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 240, 30));

        enviar.setText("Send");
        enviar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                enviarMousePressed(evt);
            }
        });
        jPanel1.add(enviar, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 610, -1, -1));

        txtMensage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMensageActionPerformed(evt);
            }
        });
        jPanel1.add(txtMensage, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 610, 540, -1));

        jScrollPane1.setViewportView(listMsg);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, 790, 370));
        jPanel1.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1180, 760));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1178, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void AtualizaChat() {
        SwingWorker pessoasOnline = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                while (true) {
                    cliente = new Cliente(ConfGlobal.ip, 15500);
                    System.out.println("Remetente: " + RecebeDados.getNome());
                    System.out.println("Destinatário: " + RecebeMensagem.getEmailDestinatario());
                    cliente.enviar_mensagem(new Mensagem(RecebeDados.getNome(), "7", RecebeMensagem.getEmailDestinatario()));
                    List<Mensagem> listaDeMensagens = (List<Mensagem>) cliente.receber_mensagem();

                    DefaultListModel dlm = new DefaultListModel();
                    dlm.addAll(listaDeMensagens);
                    listMsg.setModel(dlm);
                }
            }
        };
        pessoasOnline.execute();
    }
    private void voltar(){
        
    }
    private void enviarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_enviarMousePressed
        //quando eu enviar eu tenho que falar pro servidor enviar minha mensagem...
        String mensagemEnviar = txtMensage.getText();
        txtMensage.setText("");
        try {
            cliente = new Cliente(ConfGlobal.ip, 15500);
            cliente.enviar_mensagem(new Mensagem(RecebeDados.getEmail(), "4", RecebeDados.getNome(), RecebeDados.getSenha()));
            //enviando a mensagem...
            cliente.enviar_mensagem(new Mensagem(RecebeDados.getNome(), mensagemEnviar, RecebeMensagem.getEmailDestinatario()));
        } catch (Exception ex) {
            Logger.getLogger(PV.class.getName()).log(Level.SEVERE, null, ex);
        }
        AtualizaChat();  //--> objetivo dele: atualizar o list de mensagens...
    }//GEN-LAST:event_enviarMousePressed

    private void sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairActionPerformed
       try {
            // TODO add your handling code here:
            cliente = new Cliente(ConfGlobal.ip, 15500);
            cliente.enviar_mensagem(new Mensagem(RecebeDados.getEmail(), "6", RecebeDados.getNome(), RecebeDados.getSenha()));
            
                cliente.enviar_mensagem("estou saindo");
                cliente.finalizar();
                dispose();
        } catch (Exception ex) {
            Logger.getLogger(PV.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_sairActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated

    }//GEN-LAST:event_formWindowActivated

    private void txtMensageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMensageActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMensageActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        TelaChat redirecionar = new TelaChat(RecebeDados);
            redirecionar.setVisible(true);
            dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PV().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton enviar;
    private javax.swing.JLabel fotofundo;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> listMsg;
    private javax.swing.JLabel nomeUsuarioLbl;
    private javax.swing.JButton sair;
    private javax.swing.JTextField txtMensage;
    // End of variables declaration//GEN-END:variables
}
