package tela;

import aula_03_sockets_multicliente.Cliente;
import aula_03_sockets_multicliente.Mensagem;
import aula_03_sockets_multicliente.usuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {

    Cliente cliente = null;
    private usuarios dadosEnviar;
    public Login() {
        initComponents();
        this.setLocationRelativeTo(null);
        baixaImagemfundo();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtEmail = new javax.swing.JTextField();
        txtSenha = new javax.swing.JPasswordField();
        logarBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        fundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtEmail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 220, 300, -1));

        txtSenha.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 340, 300, -1));

        logarBtn.setText("Logar");
        logarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logarBtnActionPerformed(evt);
            }
        });
        jPanel1.add(logarBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 490, 100, 40));

        jLabel1.setText("Não possui cadastro?");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 610, -1, -1));

        jLabel2.setForeground(new java.awt.Color(153, 102, 255));
        jLabel2.setText("Cadastrar");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel2MousePressed(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 610, 70, -1));
        jPanel1.add(fundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 643));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void logarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logarBtnActionPerformed
        try {
            cliente = new Cliente(ConfGlobal.ip, 15500);
            String email = txtEmail.getText();
            String senha = (new String(txtSenha.getPassword()));
            cliente.enviar_mensagem(new Mensagem(email, "2", senha, ""));
            dadosEnviar = new usuarios();
            dadosEnviar.setEmail(email);
            dadosEnviar.setSenha(senha);
            String mensagem = (String) cliente.receber_mensagem();
            if (mensagem.equalsIgnoreCase("Login feito com sucesso")) {
               String mensagemNome = (String) cliente.receber_mensagem();
                //System.out.println(mensagemNome);
                dadosEnviar.setNome(mensagemNome);
                System.out.println("entrei");
                JOptionPane.showMessageDialog(null, "Login certo!", "Bem-vindo(a)!", JOptionPane.INFORMATION_MESSAGE);
                TelaChat redirecionar = new TelaChat(dadosEnviar);
                redirecionar.setVisible(true);
                dispose();
            }else{
            if (mensagem.equalsIgnoreCase("a")) 
                JOptionPane.showMessageDialog(null, "Login errado!", "ERRO!", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("erro...");
        }


    }//GEN-LAST:event_logarBtnActionPerformed

    private void jLabel2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MousePressed
        // TODO add your handling code here:
        Cadastro redirecionar = new Cadastro();
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel2MousePressed
    private void baixaImagemfundo() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\imagem\\Chat.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(893, 643, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void logando() {
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel fundo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton logarBtn;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
