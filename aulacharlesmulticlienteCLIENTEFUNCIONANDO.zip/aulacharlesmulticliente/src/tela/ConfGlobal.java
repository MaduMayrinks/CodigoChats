package tela;

public class ConfGlobal {
    public static String ip = "10.90.36.51";
}
