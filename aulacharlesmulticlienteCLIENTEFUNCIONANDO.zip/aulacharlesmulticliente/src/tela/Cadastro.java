/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tela;

import aula_03_sockets_multicliente.Cliente;
import aula_03_sockets_multicliente.Mensagem;
import aula_03_sockets_multicliente.usuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author 0068956
 */
public class Cadastro extends javax.swing.JFrame {

    /**
     * Creates new form Cadastro
     */
    Cliente cliente = null;
    private usuarios dadosEnviar;
    public Cadastro() {
        initComponents();
        this.setLocationRelativeTo(null);
        labelErro.setVisible(false);
        baixaImagemfundo();
    }

    private void baixaImagemfundo() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\imagem\\Chat_2.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(893, 643, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(Cadastro.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtnome = new javax.swing.JTextField();
        txtemail = new javax.swing.JTextField();
        txtsenha = new javax.swing.JPasswordField();
        labelErro = new javax.swing.JLabel();
        cadastrar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        fotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtnome.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtnome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnomeActionPerformed(evt);
            }
        });
        jPanel1.add(txtnome, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 230, 250, -1));

        txtemail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, 250, -1));

        txtsenha.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtsenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 430, 250, -1));

        labelErro.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        labelErro.setForeground(new java.awt.Color(255, 51, 51));
        labelErro.setText("Email já está em uso");
        jPanel1.add(labelErro, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 350, -1, 20));

        cadastrar.setText("Cadastrar");
        cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarActionPerformed(evt);
            }
        });
        jPanel1.add(cadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 535, 100, 30));

        jLabel1.setBackground(new java.awt.Color(153, 102, 255));
        jLabel1.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 102, 255));
        jLabel1.setText("Logar");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel1MousePressed(evt);
            }
        });
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 590, -1, -1));
        jPanel1.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 650));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtnomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnomeActionPerformed
        // TODO add your handling code here:]

    }//GEN-LAST:event_txtnomeActionPerformed

    private void cadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarActionPerformed
        try {
            cliente = new Cliente(ConfGlobal.ip, 15500);
            String email = txtemail.getText();
            String nome = txtnome.getText();
            String senha = (new String(txtsenha.getPassword()));
            cliente.enviar_mensagem(new Mensagem(email, "1", nome, senha));
            
            String mensagem = (String) cliente.receber_mensagem();
            System.out.println(mensagem);
            while (mensagem.equalsIgnoreCase("Esse email ja esta sendo utilizado")) {
                labelErro.setVisible(true);
                String opnome = txtnome.getText();
                cliente.enviar_mensagem(opnome);
            }
            if (mensagem.equalsIgnoreCase("cadastro feito com sucesso")) {
                dadosEnviar = new usuarios();
                dadosEnviar.setEmail(email);
                dadosEnviar.setNome(nome);
                dadosEnviar.setSenha(senha);
                JOptionPane.showMessageDialog(null, "Cadastro feito!", "Bem-vindo(a)!", JOptionPane.INFORMATION_MESSAGE);
                TelaChat redirecionar = new TelaChat(dadosEnviar);
                redirecionar.setVisible(true);
                dispose();

            }
        } catch (Exception ex) {
            Logger.getLogger(Cadastro.class.getName()).log(Level.SEVERE, null, ex);
        }


    }//GEN-LAST:event_cadastrarActionPerformed

    private void jLabel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MousePressed
        // TODO add your handling code here:
        Login redirecionar = new Login();
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel1MousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cadastrar;
    private javax.swing.JLabel fotofundo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelErro;
    private javax.swing.JTextField txtemail;
    private javax.swing.JTextField txtnome;
    private javax.swing.JPasswordField txtsenha;
    // End of variables declaration//GEN-END:variables
}
