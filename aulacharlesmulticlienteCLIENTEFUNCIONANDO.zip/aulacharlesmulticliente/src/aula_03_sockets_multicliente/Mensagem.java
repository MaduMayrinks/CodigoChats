package aula_03_sockets_multicliente;

import java.io.Serializable;

public class Mensagem implements Serializable {

    private String email;
    private String texto;
    private String senha;
    private String nome;
    private String emailDestinatario;
    private String nomeRemetente;

    public Mensagem(String email, String texto, String senha, String nome) {
        this.email = email;
        this.texto = texto;
        this.senha = senha;
        this.nome = nome;
    }

    public Mensagem(String nomeRemetente, String texto, String emailDestinatario) {
        this.nomeRemetente = nomeRemetente;
        this.texto = texto;
        this.emailDestinatario = emailDestinatario;
    }

    public String getNomeRemetente() {
        return nomeRemetente;
    }

    public void setNomeRemetente(String nomeRemetente) {
        this.nomeRemetente = nomeRemetente;
    }

    public String getEmailDestinatario() {
        return emailDestinatario;
    }

    public void setEmailDestinatario(String emailDestinatario) {
        this.emailDestinatario = emailDestinatario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    @Override
    public String toString() {
        return nomeRemetente + ": " + texto;
    }

}
