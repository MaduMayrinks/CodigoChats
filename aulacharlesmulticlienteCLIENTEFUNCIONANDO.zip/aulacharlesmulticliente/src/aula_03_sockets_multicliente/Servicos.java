package aula_03_sockets_multicliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Servicos {

    public void gravarClientes(usuarios dados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO atividaderedes.usuarios(nome, email, senha) "
                    + " VALUES (?,?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, dados.getNome());
            insercao.setString(2, dados.getEmail());
            insercao.setString(3, dados.getSenha());
            insercao.executeUpdate();
            System.out.println("entreiiiii");
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(Servicos.class.getName()).log(Level.SEVERE, null, ex);
             ex.printStackTrace();
        }
    }
    public boolean removerUsuarioBD(String id, String nome) {
    try {
        Connection c = Conexao.obeterConexao();
        String sql = "DELETE FROM atividaderedes.usuarios WHERE id = ? AND nome = ?";
        PreparedStatement consulta = c.prepareStatement(sql);
        consulta.setString(1, id);
        consulta.setString(2, nome);

        int linhasAfetadas = consulta.executeUpdate();

        c.close();

      return linhasAfetadas>0;//true
      
    } catch (SQLException ex) {
        Logger.getLogger(Servicos.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println("Erro: " + ex.getMessage());
    }return false;
}
    
    public boolean verificanomeBD(String nome) {

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT COUNT(*) FROM atividaderedes.usuarios WHERE nome = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int count = resultado.getInt(1);
                c.close();
                return count > 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Servicos.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return false; //retorna false se nao existir
    }
    
      public boolean verificaIdBD(String id) {

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT COUNT(*) FROM atividaderedes.usuarios WHERE id = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, id);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int count = resultado.getInt(1);
                c.close();
                return count > 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Servicos.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return false; //retorna false se nao existir
    }

     public void gravarMensagens(Mensagem mensagens) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO atividaderedes.mensagens(texto,nome) "
                    + " VALUES (?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, mensagens.getTexto());
            insercao.setString(2, mensagens.getNome());
            insercao.executeQuery();
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(Servicos.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    public boolean pegarnome(String nome) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT COUNT(*) FROM atividaderedes.usuarios WHERE nome = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int count = resultado.getInt(1);

                c.close();
                return count > 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Servicos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }
    public List<String> listarNomesClientes() {
        List<String> nomes = new ArrayList<>();

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT nome FROM atividaderedes.usuarios"; // Modifiquei a consulta para obter todos os nomes.
            PreparedStatement consulta = c.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery();

            while (resultado.next()) {
                String nome = resultado.getString("nome");
                nomes.add(nome);
            }

            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(Servicos.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }

        return nomes;
    }
}