
package Controle;

import Moddel.usuarios;
import Servicos.ServicoUsuario;

public class ControleUsuario {
    ServicoUsuario servicos;
    
    public boolean GravandoClientes(usuarios dados){
        servicos = new ServicoUsuario();
        return servicos.gravarClientes(dados);
    }
    
    public boolean RemovendoUsuario(String email, String nome, String senha){
        servicos = new ServicoUsuario();
        return servicos.removerUsuarioBD(email, nome, senha);
    }
    
    public boolean VerificandoEmail(String email){
        servicos = new ServicoUsuario();
        return servicos.verificaemailBD(email);
    }
    
     public boolean VerificandoSenha(String senha){
        servicos = new ServicoUsuario();
        return servicos.verificasenhaBD(senha);
    }
     
      public String RetornandoNome(String email){
        servicos = new ServicoUsuario();
        return servicos.RetornaNome(email);
    }
      
       public boolean atualizandoEstadoUsuario(int estado, String email){
        servicos = new ServicoUsuario();
        return servicos.atualizarEstadoUsuario(estado, email);
    }
}
