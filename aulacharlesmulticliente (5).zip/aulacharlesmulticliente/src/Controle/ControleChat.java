package Controle;

import aula_03_sockets_multicliente.Mensagem;
import Servicos.ServicoChat;
import java.util.ArrayList;
import java.util.List;

public class ControleChat {

    private ServicoChat chat;

    public List<Mensagem> ListandoMensagensPriv() {
        chat = new ServicoChat();
        return chat.listarMensagensPv();
    }

    public ArrayList<String> ListandoUsuarios() {
        chat = new ServicoChat();
        return chat.ListaUsuario();
    }

    public ArrayList<Mensagem> GravandoMensagemPv(Mensagem mensagens) {
        chat = new ServicoChat();
        return chat.gravarMensagensPV(mensagens);
    }

    public ArrayList<Mensagem> GravandoMensagemGeral(Mensagem mensagens) {
        chat = new ServicoChat();
        return chat.gravarMensagensGeral(mensagens);
    }

    public List<Mensagem> TabelaPrivada(Mensagem mensagens) {
        chat = new ServicoChat();
        return chat.tabelaPrivada(mensagens);
    }

    public ArrayList<Mensagem> TabelaAberta(Mensagem mensagens) {
        chat = new ServicoChat();
        return chat.tabelaaberta(mensagens);
    }
}
