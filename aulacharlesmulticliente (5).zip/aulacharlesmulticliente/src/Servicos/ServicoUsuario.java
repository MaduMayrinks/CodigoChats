package Servicos;

import Connection.Conexao;
import Moddel.usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServicoUsuario {

    public boolean gravarClientes(usuarios dados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO atividaderedes.usuarios(nome,email,senha) "
                    + " VALUES (?,?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, dados.getNome());
            insercao.setString(2, dados.getEmail());
            insercao.setString(3, dados.getSenha());
            insercao.executeUpdate();

            c.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ServicoChat.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
        }
        return false;
    }

    public boolean removerUsuarioBD(String email, String nome, String senha) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "DELETE FROM atividaderedes.usuarios WHERE email = ? AND nome = ? AND senha = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, email);
            consulta.setString(2, nome);
            consulta.setString(3, senha);

            int linhasAfetadas = consulta.executeUpdate();

            c.close();

            return linhasAfetadas > 0;//true

        } catch (SQLException ex) {
            Logger.getLogger(ServicoChat.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return false;
    }

    public boolean verificaemailBD(String email) {

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT COUNT(*) FROM atividaderedes.usuarios WHERE email = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, email);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int count = resultado.getInt(1);
                c.close();
                return count > 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicoChat.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return false; //retorna false se nao existir
    }

    public boolean verificasenhaBD(String senha) {

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT COUNT(*) FROM atividaderedes.usuarios WHERE senha = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, senha);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int count = resultado.getInt(1);
                c.close();
                return count > 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicoChat.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return false; //retorna false se nao existir
    }

    public String RetornaNome(String email) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT nome FROM atividaderedes.usuarios WHERE email = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, email);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String nome = resultado.getString("nome");
                c.close();
                return nome;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicoChat.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
        // Retorna null se não encontrar o e-mail no banco de dados.
    }

    public boolean atualizarEstadoUsuario(int estado, String email) {

        try {
            Connection c = Conexao.obeterConexao();

            // A consulta SQL para atualização do estado
            String sql = "UPDATE atividaderedes.usuarios SET estado = ? WHERE email = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            // Configurando os parâmetros para a atualização
            atualizacao.setInt(1, estado);
            atualizacao.setString(2, email);

            // Executando a atualização
            int linhasAfetadas = atualizacao.executeUpdate();

            // Verificando se a atualização foi bem-sucedida
            if (linhasAfetadas > 0) {
                // Se a atualização deu certo, retorna true

                return true;
            }

            // Fechando a conexão
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicoChat.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
