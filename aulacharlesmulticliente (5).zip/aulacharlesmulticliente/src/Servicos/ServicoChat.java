package Servicos;

import Connection.Conexao;
import Moddel.usuarios;
import aula_03_sockets_multicliente.Mensagem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ServicoChat {

    public List<Mensagem> listarMensagensPv() {
        List<Mensagem> nomes = new ArrayList<>();

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT nome FROM atividaderedes.usuarios"; // Modifiquei a consulta para obter todos os nomes.
            PreparedStatement consulta = c.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery();

            while (resultado.next()) {
                String nome = resultado.getString("nome");
                String senha = resultado.getString("senha");
                String email = resultado.getString("email");
                String texto = resultado.getString("texto");
                Mensagem adicionaelemt = new Mensagem(email, texto, senha, nome);
                nomes.add(adicionaelemt);
            }

            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicoChat.class.getName()).log(Level.SEVERE, null, ex);
        }

        return nomes;
    }

    public ArrayList<Mensagem> gravarMensagensPV(Mensagem mensagens) {
        ArrayList<Mensagem> listaMensagens = new ArrayList<>();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO atividaderedes.mensagens(mensagem,destinatarionome,remetenteemail)"
                    + " VALUES (?,?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, mensagens.getTexto());
            insercao.setString(2, mensagens.getEmailDestinatario()); //destinatario
            insercao.setString(3, mensagens.getNomeRemetente()); //remetente
            insercao.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ServicoChat.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaMensagens;

    }

    public ArrayList<Mensagem> gravarMensagensGeral(Mensagem mensagens) {
        ArrayList<Mensagem> ListaMensagemGeral = new ArrayList<>();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO atividaderedes.mensagensGerais(mensagem,usuario)"
                    + " VALUES (?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, mensagens.getTexto()); //mensagem
            insercao.setString(2, mensagens.getNomeRemetente());//nome de quem enviou
            insercao.executeUpdate();

            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicoChat.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ListaMensagemGeral;
    }

    public List<Mensagem> tabelaPrivada(Mensagem mensagens) {
        List<Mensagem> mensagensPrivadas = new ArrayList<>();
        //String sql = "SELECT remetenteemail, mensagem, destinatarionome FROM atividaderedes.mensagens WHERE (destinatarionome = ? AND remetenteemail = ?) OR (destinatarionome = ? AND remetenteemail = ?)";
        String sql = "SELECT remetenteemail, mensagem, destinatarionome FROM atividaderedes.mensagens WHERE (destinatarionome = ? AND remetenteemail = ?) OR (remetenteemail = ? AND destinatarionome = ?) ORDER BY data_mensagem ";

        try {
            Connection c = Conexao.obeterConexao();
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, mensagens.getEmailDestinatario());
            ps.setString(2, mensagens.getNomeRemetente());
            ps.setString(3, mensagens.getEmailDestinatario());
            ps.setString(4, mensagens.getNomeRemetente());
            /*
            Result.setString(5, mensagens.getNomeRemetente());
            Result.setString(6, mensagens.getEmailDestinatario());*/

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Mensagem atual = new Mensagem(mensagens.getNome(), mensagens.getTexto(), mensagens.getEmailDestinatario());
                atual.setEmailDestinatario(rs.getString("destinatarionome"));
                atual.setTexto(rs.getString("mensagem"));
                atual.setNomeRemetente(rs.getString("remetenteemail"));

                mensagensPrivadas.add(atual);
            }
            c.close();
        } catch (SQLException ex) {
            System.out.println("Ocorreu um erro ao buscar as mensagens da comunidade: " + ex.getMessage());
        }

        return mensagensPrivadas;
    }

    public ArrayList<Mensagem> tabelaaberta(Mensagem mensagens) {
        ArrayList<Mensagem> mensagensPrivadas = new ArrayList<>();

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT mensagem,usuario FROM atividaderedes.mensagensgerais;";
            PreparedStatement Result = c.prepareStatement(sql);

            ResultSet resultado = Result.executeQuery();

            while (resultado.next()) {
                Mensagem atual = new Mensagem(mensagens.getEmail(), mensagens.getTexto(), mensagens.getSenha(), mensagens.getNome());
                atual.setTexto(resultado.getString("mensagem"));
                //atual.setEmail(resultado.getString("usuario"));
                atual.setNomeRemetente(resultado.getString("usuario"));
                
                mensagensPrivadas.add(atual);
            }

            c.close();
        } catch (SQLException ex) {
            System.out.println("Ocorreu um erro ao buscar as mensagens da comunidade: " + ex.getMessage());
        }

        return mensagensPrivadas;
    }

    public ArrayList<String> ListaUsuario() {
        ArrayList<String> listaUsers = new ArrayList<>();

        try {
            Connection c = Conexao.obeterConexao();

            String sql = "SELECT nome FROM atividaderedes.usuarios WHERE estado = 1 ORDER BY nome ASC;";
            PreparedStatement trans = c.prepareStatement(sql);
            ResultSet resultadoBD = trans.executeQuery();

            while (resultadoBD.next()) {
                String nome = resultadoBD.getString("nome");
                if (listaUsers.contains(nome)) {

                } else {
                    listaUsers.add(nome);
                }
            }
            return listaUsers;

        } catch (SQLException ex) {
            System.err.println("Erro ao listar usuarios");
            ex.printStackTrace();
            return null;
        }
    }

}
