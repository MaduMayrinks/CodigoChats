package aula_03_sockets_multicliente;

import Controle.ControleChat;
import Controle.ControleUsuario;
import Servicos.ServicoChat;
import Moddel.usuarios;
import java.sql.Connection;
import java.net.Socket;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

public class TrataCliente implements Runnable {

    private Socket soquete_cliente;
    private ObjectOutputStream saida;
    private ObjectInputStream entrada;
    private List<Mensagem> mensagens;
    private List<Mensagem> usuarios;
    private String Loginnome = "";

    private ControleChat controleChat = new ControleChat();
    private ControleUsuario controleUsuario = new ControleUsuario();

    public TrataCliente(Socket soquete_cliente) throws Exception {
        super();
        this.soquete_cliente = soquete_cliente;
        this.saida = new ObjectOutputStream(this.soquete_cliente.getOutputStream());
        this.entrada = new ObjectInputStream(this.soquete_cliente.getInputStream());

    }

    public void enviar_mensagem(Object mensagem) throws Exception {
        this.saida.writeObject(mensagem);

    }

    public Object receber_mensagem() throws Exception {
        return this.entrada.readObject();
    }

    public void finalizar() throws IOException {
        this.soquete_cliente.close();
    }

    @Override
    public void run() {

        String nomeusuario = " ";
controleChat = new ControleChat();
        try {
            Mensagem mensagem;

            //conexao no BD
            mensagem = (Mensagem) receber_mensagem();
            //System.out.print("Nome:" + mensagem.getNome() + "\n");
            //System.out.print("Texto:" + mensagem.getTexto());
            
            if (mensagem.getTexto().equals("1")) {

                while (controleUsuario.VerificandoEmail(mensagem.getEmail()) == true) {

                    enviar_mensagem("Esse email ja esta sendo utilizado");
                    String email = (String) receber_mensagem();
                    mensagem.setEmail(email);
                }

                String email = mensagem.getEmail();
                String senha = mensagem.getSenha();
                String nome = mensagem.getNome();
                int estado = 1;
                usuarios repassavalores = new usuarios();
                repassavalores.setNome(nome);
                repassavalores.setEmail(email);
                repassavalores.setSenha(senha);
                repassavalores.setEstado(estado);
                nomeusuario = nome;
                if (controleUsuario.GravandoClientes(repassavalores) == true) {
                    enviar_mensagem("cadastro feito com sucesso");
                    controleUsuario.atualizandoEstadoUsuario(estado, repassavalores.getEmail());

                }

            }
            if (mensagem.getTexto().equals("2")) {
                if (controleUsuario.VerificandoEmail(mensagem.getEmail()) == true && (controleUsuario.VerificandoSenha(mensagem.getSenha()) == true)) {
                    int estado = 1;
                    //mandando o nome do usuario pro usuario
                    enviar_mensagem("Login feito com sucesso");
                    enviar_mensagem(controleUsuario.RetornandoNome(mensagem.getEmail()));

                    controleUsuario.atualizandoEstadoUsuario(estado, mensagem.getEmail());
                } else {
                    enviar_mensagem("a");

                }
            }
            if (mensagem.getTexto().equals("3")) {
                enviar_mensagem(controleChat.ListandoUsuarios());
                
            }
            if (mensagem.getTexto().equals("4")) {

                //recebendo o nome do cara que vai mandar mensagem
                Mensagem usuarioselecionado = (Mensagem) receber_mensagem();
                //enviando tudo que está gravado
                enviar_mensagem(controleChat.GravandoMensagemPv(usuarioselecionado));

            }
            if (mensagem.getTexto().equals("7")) {
                //enviando tudo que está gravado
                System.out.println("O REMETENTE: " + mensagem.getNomeRemetente()+" Email dest: "+mensagem.getEmailDestinatario()+" mensagem: "+mensagem.getTexto()
                );
                enviar_mensagem(controleChat.TabelaPrivada(mensagem));
               
            }

            if (mensagem.getTexto().equals("5")) {
                Mensagem textochat = (Mensagem) receber_mensagem();
                System.out.println("Mensagem: "+textochat+ " - Nome Remetente: "+textochat.getNomeRemetente()+" Mens.: "+textochat.getTexto()+" Email Dest.: "+textochat.getEmailDestinatario());
                enviar_mensagem(controleChat.GravandoMensagemGeral(textochat));

            }
            if (mensagem.getTexto().equals("8")) {
                //System.out.println(controleChat.TabelaAberta(mensagem));
                enviar_mensagem(controleChat.TabelaAberta(mensagem));

            }

            if (mensagem.getTexto().equals("6")) {
                String estadosair;
                estadosair = (String) receber_mensagem();
                int estado = 0;
               if(estadosair.equalsIgnoreCase("estou saindo"))
                controleUsuario.atualizandoEstadoUsuario(estado, mensagem.getEmail());
            }

        } catch (Exception e) {
            e.printStackTrace();

        }

    }

}
